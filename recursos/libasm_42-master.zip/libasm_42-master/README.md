# libasm_42
The aim of this project is to get familiar with assembly language.
